🚽 toilet — Anti-theft alarm for macOS
========================================

QUICK INSTALL:
  sudo cp toilet /usr/local/bin/toilet

SETUP:
  1. brew install imagesnap
  2. toilet setup
  3. toilet test
  4. sudo toilet

Full docs: https://github.com/dzulfikar08/toilet
